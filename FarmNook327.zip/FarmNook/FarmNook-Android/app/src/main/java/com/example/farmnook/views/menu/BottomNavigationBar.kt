package com.example.farmnook.views.menu

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.farmnook.R
import com.example.farmnook.views.hauler.delivery_management.DashboardFragment
import com.google.android.material.bottomnavigation.BottomNavigationView

class BottomNavigationBar : AppCompatActivity() {
    private lateinit var bottomNavigationView: BottomNavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bottom_navigation)

        bottomNavigationView = findViewById(R.id.bottom_nav)

        bottomNavigationView.setOnItemSelectedListener { menu ->
            when(menu.itemId){
                R.id.home -> {
                    replaceFragment(DashboardFragment())
                    true
                }R.id.history -> {
                replaceFragment(DashboardFragment())
                true
            }R.id.delivery -> {
                replaceFragment(DashboardFragment())
                true
            }R.id.message -> {
                replaceFragment(DashboardFragment())
                true
            }
                else -> false
            }
        }
        replaceFragment(DashboardFragment())
    }
    private fun replaceFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.navHost, fragment)
            .commit()
    }
}

