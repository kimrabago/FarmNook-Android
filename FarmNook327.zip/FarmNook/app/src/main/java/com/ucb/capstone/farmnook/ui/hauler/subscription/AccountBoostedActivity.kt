package com.ucb.capstone.farmnook.ui.hauler.subscription

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.ucb.capstone.farmnook.R

class AccountBoostedActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_account_boosted)

    }
}