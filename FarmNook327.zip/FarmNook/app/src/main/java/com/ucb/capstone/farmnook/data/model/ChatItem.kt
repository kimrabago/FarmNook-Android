package com.ucb.capstone.farmnook.data.model

data class ChatItem(
    val chatId: String,
    val userName: String,
    val lastMessage: String
)
