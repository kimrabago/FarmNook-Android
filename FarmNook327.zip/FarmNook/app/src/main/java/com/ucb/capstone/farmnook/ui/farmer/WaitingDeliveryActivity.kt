package com.ucb.capstone.farmnook.ui.farmer

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.ucb.capstone.farmnook.R

class WaitingDeliveryActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_waiting_delivery)

    }
}