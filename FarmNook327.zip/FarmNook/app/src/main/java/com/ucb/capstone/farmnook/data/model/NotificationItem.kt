package com.ucb.capstone.farmnook.data.model

data class NotificationItem(
    val userName: String,
    val notifMessage: String,
    val dateTime: String
)
