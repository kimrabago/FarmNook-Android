package com.ucb.capstone.farmnook.data.service

class MyFirebaseMessaging {
}