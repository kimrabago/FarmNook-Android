package com.ucb.capstone.farmnook.ui.farmer

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.ucb.capstone.farmnook.R

class DeliveryConfirmationActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_delivery_confirmation)

    }
}