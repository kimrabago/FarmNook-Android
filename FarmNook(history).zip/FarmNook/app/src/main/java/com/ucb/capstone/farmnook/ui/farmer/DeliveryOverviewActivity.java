package com.ucb.capstone.farmnook.ui.farmer;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.ucb.capstone.farmnook.R;

public class DeliveryOverviewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delivery_overview);

    }
}